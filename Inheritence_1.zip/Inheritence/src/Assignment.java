import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;

import static java.lang.Integer.parseInt;

import java.io.*;
import java.util.StringTokenizer;

import static java.lang.Integer.parseInt;

public class Assignment {


    public static void main(String[] args) throws IOException {
        String str1 = "Paper";
        String str2 = "Coin";
        File text = new File("//media/arka97csedu/3CC0FDFDC0FDBCE8/java codes/Inheritence/info.txt");
        int lines = 0;
        Scanner br = new Scanner(text);
        while (br.hasNextLine()) lines++;
        System.out.println(lines);
        Wallet wallet = new Wallet(lines);
        br.close();
        Scanner brb = new Scanner(new FileReader("info.txt"));
        String line;
        while ((brb.hasNextLine())) {
            line = brb.nextLine();
            System.out.println(line);
            StringTokenizer st = new StringTokenizer(line);
            int k = 0;
            String[] part = new String[4];
            while (st.hasMoreTokens()) {
                part[k] = st.nextToken();
                k++;
                }
            System.out.println(part[0]);
            if (part[0] == str1) {
                boolean auto = false;
                int val = parseInt(part[0]);
                    // System.out.println(val);
                String state = part[3];
                System.out.println(state);
                String s = part[2];
                if (s =="autographed")
                    auto = true;
                    //System.out.println(auto);
                wallet.addpapermoney(val, state, auto);
                }
                else {
                    boolean gold = false;
                    int val = parseInt(part[1]);
                    System.out.println(val);
                    String stat = part[2];

                    if (stat == "gold") {
                        gold = true;
                    }
                    System.out.println(gold);
                    wallet.addcoinmoney(val, gold);

                }
            }


        brb.close();
        wallet.printsummery();
        wallet.printtotalvalue();
    }




    }

