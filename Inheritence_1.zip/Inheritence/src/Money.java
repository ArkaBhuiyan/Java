abstract class Money {
    protected int value;
    Money(int value )
    {
        this.value=value;
    }
    protected int getvalue()
    {
        return value;
    }
}
