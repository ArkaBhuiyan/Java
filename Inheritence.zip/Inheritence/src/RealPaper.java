public class RealPaper extends Paper {
    RealPaper(int value, String state, boolean autographed) {
        super(value, state, autographed);
    }
    protected int getvalue()
    {
       return super.getvalue();
    }
}
