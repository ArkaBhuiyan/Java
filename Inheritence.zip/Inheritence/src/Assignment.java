import java.io.*;

public class Assignment {


    public static void main(String[] args) throws IOException {
        String str1 = "Paper";
        String str2 = "Coin";
        int lines=0;
        BufferedReader br = new BufferedReader(new FileReader("info.txt"));
        try {
            while (br.readLine() != null) lines++;
        }
        catch (FileNotFoundException e)
        {
            System.out.println("Error reading file.");
        } catch (IOException e) {
            System.out.println("Error reading file.");
        }
        Wallet wallet = new Wallet(lines);
        br.close();
        BufferedReader brb = new BufferedReader(new FileReader("info.txt"));
         try
         {
             String line;
             while ((line=brb.readLine())!=null)
             {
                 System.out.println(line);
                 String[] part = line.split(" ");
                 System.out.print(part[0]);
                 if(part[0]==str1)
                 {
                     boolean auto = false;
                     int val = Integer.parseInt(part[1]);
                     // System.out.println(val);
                     String state = part[3];
                     System.out.println(state);

                     String st = part[2];
                     if (st=="autographed")
                         auto=true;
                     //System.out.println(auto);
                     wallet.addpapermoney(val,state,auto);
                 }
                 else
                 {
                     boolean gold=false;
                     int val = Integer.parseInt(part[1]);
                     System.out.println(val);
                     String stat = part[2];

                     if(stat=="gold")
                     {
                         gold=true;
                     }
                     System.out.println(gold);
                     wallet.addcoinmoney(val,gold);

                 }
             }
         }
         catch (FileNotFoundException e)
         {
             System.out.println("Error reading file.");
         }
         catch (IOException e) {
             System.out.println("Error reading file.");
         }
         brb.close();
         wallet.printsummery();
         wallet.printtotalvalue();


    }
}
