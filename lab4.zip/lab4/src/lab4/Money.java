
package lab4;

public abstract class Money {
    
    int value;
    String property;
    public abstract int getTrueValue();
    
}
