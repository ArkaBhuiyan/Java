
package lab4;


public class RealPaper extends Paper {
    
    public RealPaper(int val,String property){
        super(val, property);
        
    }
}
