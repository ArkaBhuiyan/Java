
package lab4;


public class FakePaper extends Paper {
    
    public FakePaper(int val, String property){
        super(val, property);
        
    }
    public int getTrueValue(){
        return 0;
    }
}
